from joblib import load
import pandas as pd
import numpy as np

# Load the 4 models
model_1 = load('blueberry_model.pkl')
model_2 = load('chocolate_model.pkl')
model_3 = load('croissant_model.pkl')
model_4 = load('red_velvet_model.pkl')

# Load data for predictions (ensure the data matches the model's training format)
x_test_1 = pd.read_excel('Blueberry_Muffin_Metrics_Clean_predict_data.csv.xlsx')
x_test_2 = pd.read_excel('Chocolate Cake_predict_data.csv.xlsx')
x_test_3 = pd.read_excel('Croissant_Metrics_Clean_predict_data.csv.xlsx')
x_test_4 = pd.read_excel('Red_Velvet_Metrics_Clean_predict_data.csv.xlsx')

# Make predictions with each model
predictions_1 = model_1.predict(x_test_1)
predictions_2 = model_2.predict(x_test_2)
predictions_3 = model_3.predict(x_test_3)

predictions_4 = model_4.predict(x_test_4)

# Convert predictions to integers
predictions_1_int = np.round(predictions_1).astype(int)
predictions_2_int = np.round(predictions_2).astype(int)
predictions_3_int = np.round(predictions_3).astype(int)
predictions_4_int = np.round(predictions_4).astype(int)

# Print predictions
print("Predictions from Model 1 (as integers):", predictions_1_int)
print("Predictions from Model 2 (as integers):", predictions_2_int)
print("Predictions from Model 3 (as integers):", predictions_3_int)
print("Predictions from Model 4 (as integers):", predictions_4_int)