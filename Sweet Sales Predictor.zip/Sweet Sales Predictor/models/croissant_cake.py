import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

p1_data=pd.read_csv("Croissant_Metrics_Clean.csv")
p1_data=DataFrame=pd.DataFrame(p1_data)
p1_data

problematic_rows = p1_data[~p1_data.replace([float('inf'), float('-inf')], pd.NA).notna().all(axis=1)]
p1_data.replace([float('inf'), float('-inf')], pd.NA, inplace=True)  # Replace inf/-inf with NaN
p1_data.fillna(0, inplace=True)  # Replace NaN with 0




from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error,r2_score,mean_absolute_error

numeric_p1 = p1_data.select_dtypes(include=['number'])
corr_matrix = numeric_p1.corr()
sns.heatmap(corr_matrix, cmap='coolwarm', annot=True)
plt.show()

x = p1_data.drop(columns=['Croissant Units Sold'])
y = p1_data['Croissant Units Sold']
x.head()

print(x.shape)
print(y.shape)

x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.1,random_state=42)
print(x_train.shape)
print(x_test.shape)
print(y_train.shape)
print(y_test.shape)

model = RandomForestRegressor(n_estimators=50, random_state=42)
#model=LinearRegression()
model.fit(x_train,y_train)

import joblib
joblib.dump(model, 'D:\\python\\project of data since\\main\\models\\croissant_model.pkl')


pred=model.predict(x_test)

mae = mean_absolute_error(y_test, pred)
mse = mean_squared_error(y_test, pred)
rmse = np.sqrt(mse)
r2 = r2_score(y_test, pred)

# Print metrics
print(f"Mean Absolute Error (MAE): {mae}")
print(f"Mean Squared Error (MSE): {mse}")
print(f"Root Mean Squared Error (RMSE): {rmse}")
print(f"R^2 Score: {r2}")

import matplotlib.pyplot as plt

# Plot actual vs. predicted values
plt.figure(figsize=(8, 6))
plt.scatter(y_test, pred, alpha=0.6, label="Predicted vs. Actual")  # Add label for legend
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()],color='red', linestyle='--', label="Ideal Fit (y = x)")  # Add label for line

# Add titles and labels
plt.title("Actual vs. Predicted Values", fontsize=14)
plt.xlabel("Actual Values", fontsize=12)
plt.ylabel("Predicted Values", fontsize=12)

# Add legend
plt.legend(fontsize=10)
plt.grid()
plt.savefig("croissant_map.png")
plt.show()

import numpy as np
# Assuming 'predictions' is the array or list of predicted values
predictions_rounded = np.round(pred).astype(int)

print(y_test.head(10)-predictions_rounded[:10])
