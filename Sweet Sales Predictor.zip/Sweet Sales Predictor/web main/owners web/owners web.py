import streamlit as st
import pandas as pd
import altair as alt
from datetime import datetime
from PIL import Image

# Load Predictions
file_path = "predictions.csv"  # Update with your file path
data = pd.read_csv(file_path)

# Ensure 'Date' column is in datetime format
data['Date'] = pd.to_datetime(data['Date'])

# App Title
st.title("Bakery Cake Sales Predictions")

# Sidebar Filters
st.sidebar.header("Filter Options")

# Radio Buttons in Sidebar for selecting chart type
chart_type = st.sidebar.radio("Select View:", ('Select Date', 'Model Accuracy'))

# Date Selection for "Select Date" option
if chart_type == 'Select Date':
    # Date Selection (set to show dates between 23 and 27)
    min_date = datetime(2024, 12, 23)  # Example: Adjust to your range
    max_date = datetime(2024, 12, 27)
    selected_date = st.sidebar.date_input("Select Date:", value=min_date.date(), min_value=min_date.date(), max_value=max_date.date())

    # Automatically determine the corresponding weekday based on the selected date
    selected_weekday = selected_date.strftime('%A')  # Get weekday name from date

    # Filter Data (strip time component from 'Date' column for comparison)
    filtered_data = data[
        (data['Date'].dt.date == selected_date) & (data['Weekday'] == selected_weekday)
    ]

    # Display Filtered Data
    st.subheader(f"Predictions for {selected_date} ({selected_weekday})")
    if not filtered_data.empty:
        st.write(filtered_data)
    else:
        st.warning("No data available for the selected date and weekday.")

    # Sales Trends Plot
    st.subheader("Sales Trends for Bakery Items")
    chart_data = pd.melt(
        data,
        id_vars=["Date", "Weekday"],
        value_vars=["Blueberry_Model", "Chocolate_Model", "Croissant_Model", "Red_Velvet_Model"],
        var_name="Item",
        value_name="Predicted Sales"
    )
    sales_chart = alt.Chart(chart_data).mark_line().encode(
        x="Date:T",
        y="Predicted Sales:Q",
        color="Item:N",
        tooltip=["Date:T", "Item:N", "Predicted Sales:Q"]
    ).interactive()

    st.altair_chart(sales_chart, use_container_width=True)

elif chart_type == 'Model Accuracy':
    # Show Scatter Plot Images for Model Accuracy
    st.subheader("Model Accuracy - Scatter Plots")

    # Model Evaluation Details for each cake
    metrics = {
        "Blueberry Muffin Cake": {
            "Mean Absolute Error": 0.3258823529411764,
            "Mean Squared Error": 0.2435294117647058,
            "Root Mean Squared Error": 0.4934869924979845,
            "R Squared Score": 0.9767127140375548
        },
        "Chocolate Cake": {
            "Mean Absolute Error": 0.49529411764705883,
            "Mean Squared Error": 0.9481411764705883,
            "Root Mean Squared Error": 0.9737254112277178,
            "R Squared Score": 0.9435490729295426
        },
        "Croissant Cake": {
            "Mean Absolute Error": 0.42529411764705893,
            "Mean Squared Error": 0.581423529411765,
            "Root Mean Squared Error": 0.7625113306776268,
            "R Squared Score": 0.959385727234274
        },
        "Red Velvet Cake": {
            "Mean Absolute Error": 0.24705882352941172,
            "Mean Squared Error": 0.1268470588235294,
            "Root Mean Squared Error": 0.35615594733701894,
            "R Squared Score": 0.9898508305647841
        }
    }

    # Load scatter plot images (adjust file paths as necessary)
    blueberry_image = Image.open("Blueberry_map.png")  # Path to Blueberry Model scatter plot
    chocolate_image = Image.open("chocolate_map.png")  # Path to Chocolate Model scatter plot
    croissant_image = Image.open("croissant_map.png")  # Path to Croissant Model scatter plot
    redvelvet_image = Image.open("red_velvet_map.png")  # Path to Red Velvet Model scatter plot

    # Display metrics and scatter plot images
    col1, col2 = st.columns(2)

    with col1:
        st.markdown(f"### Blueberry Muffin Cake:")
        st.markdown(f"**Mean Absolute Error:**")
        st.markdown(f"{metrics['Blueberry Muffin Cake']['Mean Absolute Error']}")
        st.markdown(f"**Mean Squared Error:**")
        st.markdown(f"{metrics['Blueberry Muffin Cake']['Mean Squared Error']}")
        st.markdown(f"**Root Mean Squared Error:**")
        st.markdown(f"{metrics['Blueberry Muffin Cake']['Root Mean Squared Error']}")
        st.markdown(f"**R Squared Score:**")
        st.markdown(f"{metrics['Blueberry Muffin Cake']['R Squared Score']}")
        st.image(blueberry_image, caption="Blueberry Model Accuracy")

        st.markdown(f"### Croissant Cake:")
        st.markdown(f"**Mean Absolute Error:**")
        st.markdown(f"{metrics['Croissant Cake']['Mean Absolute Error']}")
        st.markdown(f"**Mean Squared Error:**")
        st.markdown(f"{metrics['Croissant Cake']['Mean Squared Error']}")
        st.markdown(f"**Root Mean Squared Error:**")
        st.markdown(f"{metrics['Croissant Cake']['Root Mean Squared Error']}")
        st.markdown(f"**R Squared Score:**")
        st.markdown(f"{metrics['Croissant Cake']['R Squared Score']}")
        st.image(croissant_image, caption="Croissant Model Accuracy")

    with col2:
        st.markdown(f"### Chocolate Cake:")
        st.markdown(f"**Mean Absolute Error:**")
        st.markdown(f"{metrics['Chocolate Cake']['Mean Absolute Error']}")
        st.markdown(f"**Mean Squared Error:**")
        st.markdown(f"{metrics['Chocolate Cake']['Mean Squared Error']}")
        st.markdown(f"**Root Mean Squared Error:**")
        st.markdown(f"{metrics['Chocolate Cake']['Root Mean Squared Error']}")
        st.markdown(f"**R Squared Score:**")
        st.markdown(f"{metrics['Chocolate Cake']['R Squared Score']}")
        st.image(chocolate_image, caption="Chocolate Model Accuracy")

        st.markdown(f"### Red Velvet Cake:")
        st.markdown(f"**Mean Absolute Error:**")
        st.markdown(f"{metrics['Red Velvet Cake']['Mean Absolute Error']}")
        st.markdown(f"**Mean Squared Error:**")
        st.markdown(f"{metrics['Red Velvet Cake']['Mean Squared Error']}")
        st.markdown(f"**Root Mean Squared Error:**")
        st.markdown(f"{metrics['Red Velvet Cake']['Root Mean Squared Error']}")
        st.markdown(f"**R Squared Score:**")
        st.markdown(f"{metrics['Red Velvet Cake']['R Squared Score']}")
        st.image(redvelvet_image, caption="Red Velvet Model Accuracy")

# Additional Feedback
st.sidebar.info("Use the radio buttons to select either Date or Model Accuracy.")
